import java.util.LinkedList;


public class Criteria extends LinkedList<Criterion> implements ICriteria{

	// TODO ��czenie wynik�w z wielu kryteri�w w celu oceny ruchu.

}
