import java.util.List;


public interface ICriteria extends List<Criterion>, JSONSerializable{
	;
}
