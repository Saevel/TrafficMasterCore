
public interface ICriterionResult extends Comparable{
;
}
